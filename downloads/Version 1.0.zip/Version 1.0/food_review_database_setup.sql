CREATE DATABASE  IF NOT EXISTS `food_review_project` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `food_review_project`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: food_review_project
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `rating` int DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `subtype` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
INSERT INTO `reviews` VALUES (1,'Pizza',3,'GRAIN',NULL,NULL,'2026-03-08'),(2,'Pasta',9,'GRAIN',NULL,NULL,'2026-02-24'),(3,'Apple',6,'FRUIT','Honeycrisp',NULL,'2025-09-18'),(4,'Chocolate Bar',8,'SUGARS','Dark',NULL,'2026-01-13'),(5,'Salmon',9,'SEAFOOD','Grilled',NULL,'2026-03-05'),(6,'Potato',7,'VEGETABLE','Roasted',NULL,'2026-02-28'),(7,'Blueberries',10,'FRUIT','Fresh',NULL,'2026-01-20'),(8,'Avocado',7,'VEGETABLE',NULL,NULL,'2025-02-16'),(9,'Greek Yogurt',8,'DAIRY','Plain',NULL,'2026-01-05'),(10,'Spinach',5,'VEGETABLE','Baby',NULL,'2023-03-12'),(11,'Pad Thai',9,'OTHER','Shrimp','China Wok','2024-06-17'),(12,'Lentil Soup',6,'VEGETABLE','Spicy',NULL,'2026-03-12'),(13,'Mango',6,'FRUIT',NULL,NULL,'2025-08-14'),(14,'Bread',7,'GRAIN','Sourdough',NULL,'2023-09-10'),(15,'Steak',8,'MEAT','Ribeye','Texas Roadhouse','2026-01-18'),(16,'Pizza',9,'GRAIN','Steak And Cheese','The Pizza Joint','2026-02-14'),(17,'Chicken',10,'MEAT','Tender',NULL,'2026-04-02'),(18,'Sandwich',8,'GRAIN','Ham And Bacon',NULL,'2026-04-02'),(19,'Hotdog',6,'MEAT',NULL,'Orange Blossom Opry','2026-03-27'),(20,'Mnms',7,'SUGARS','Peanut',NULL,'2025-03-12');
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-03 14:37:27
